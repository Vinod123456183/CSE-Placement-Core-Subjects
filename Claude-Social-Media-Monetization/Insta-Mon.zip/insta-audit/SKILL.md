---
name: insta-audit
description: >
  Full audit of YOUR OWN Instagram account reels from the last 30 days.
  Scrapes all recent reels via Apify, transcribes audio with OpenAI Whisper,
  analyzes performance metrics, identifies what is working vs what is not,
  and saves a 4-sheet Excel report to the Documents folder.
  Use when user says "audit my instagram", "audit my reels", "whats working
  on my instagram", "my reel performance", or "analyze my account".
user-invokable: true
argument-hint: "<your_instagram_profile_url>"
allowed-tools:
  - Bash
---

# Instagram Reels Audit - Last 30 Days - Excel Report

Pipeline: Apify scrape (last 30 days) -> audioUrl curl download -> OpenAI whisper-1 transcription -> metrics analysis -> 4-sheet Excel file in Documents.

Built by Manthan Jethwani - phazeai.com

**Requires:** `APIFY_TOKEN` and `OPENAI_API_KEY` env vars set.

---

## Step 0 - Ask if No URL Provided

If no Instagram profile URL is given, ask:
> "What is your Instagram profile URL? (e.g. https://www.instagram.com/yourusername/)"

---

## Step 1 - Scrape Last 30 Days of Reels via Apify

```bash
INSTAGRAM_URL="<YOUR_INSTAGRAM_PROFILE_URL>"

RESPONSE=$(curl -s -X POST \
  "https://api.apify.com/v2/acts/shu8hvrXbJbY3Eb9W/runs?token=$APIFY_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{
    \"directUrls\": [\"$INSTAGRAM_URL\"],
    \"resultsType\": \"posts\",
    \"resultsLimit\": 30,
    \"mediaType\": \"VIDEO\",
    \"addParentData\": false
  }")

RUN_ID=$(echo "$RESPONSE" | python3 -c "import json,sys; print(json.load(sys.stdin)['data']['id'])")
DATASET_ID=$(echo "$RESPONSE" | python3 -c "import json,sys; print(json.load(sys.stdin)['data']['defaultDatasetId'])")
echo "Apify run started: $RUN_ID"
```

---

## Step 2 - Poll Until SUCCEEDED

```bash
for i in $(seq 1 40); do
  STATUS=$(curl -s "https://api.apify.com/v2/actor-runs/$RUN_ID?token=$APIFY_TOKEN" \
    | python3 -c "import json,sys; print(json.load(sys.stdin)['data']['status'])")
  echo "Poll $i: $STATUS"
  [ "$STATUS" = "SUCCEEDED" ] && break
  [ "$STATUS" = "FAILED" ] && echo "Apify failed" && exit 1
  sleep 10
done
```

---

## Step 3 - Fetch and Save Raw Data

```bash
RAW_DATA=$(curl -s "https://api.apify.com/v2/datasets/$DATASET_ID/items?token=$APIFY_TOKEN&limit=30&format=json")

python3 -c "
import json, sys, os
data = json.loads(sys.stdin.read())
out = os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Temp', 'insta_clean.json')
with open(out, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=True)
print(f'Saved {len(data)} items to {out}')
" <<< "$RAW_DATA"
```

---

## Step 4 - Transcribe Audio via audioUrl + OpenAI Whisper API

Uses the audioUrl field from Apify directly (same logic as competitor-reels-ai skill). No yt-dlp needed.

```bash
python3 << 'PYEOF'
import json, subprocess, os
from datetime import datetime, timezone, timedelta

tmp  = os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Temp')
tdir = os.path.join(tmp, 'audit_transcripts')
os.makedirs(tdir, exist_ok=True)

data       = json.load(open(os.path.join(tmp, 'insta_clean.json'), encoding='utf-8'))
OPENAI_KEY = os.environ.get('OPENAI_API_KEY', '')
cutoff     = datetime.now(timezone.utc) - timedelta(days=30)

items = []
for item in data:
    ts = item.get('timestamp', '')
    try:
        if datetime.fromisoformat(ts.replace('Z', '+00:00')) < cutoff:
            continue
    except:
        pass
    items.append(item)

print(f'Transcribing {len(items)} reels...')

for idx, item in enumerate(items, 1):
    out_txt = os.path.join(tdir, f'reel_{idx}.txt')
    if os.path.exists(out_txt):
        print(f'  Reel {idx}: already done, skipping')
        continue

    audio_url = item.get('audioUrl') or item.get('videoUrl', '')
    if not audio_url:
        cap = item.get('caption', '')
        open(out_txt, 'w', encoding='utf-8').write(cap)
        print(f'  Reel {idx}: no audioUrl - caption saved')
        continue

    tmp_audio = os.path.join(tmp, f'audit_reel_{idx}.mp4')
    subprocess.run(['curl', '-s', '-L', audio_url, '-o', tmp_audio], capture_output=True, timeout=60)
    size = os.path.getsize(tmp_audio) if os.path.exists(tmp_audio) else 0
    print(f'  Reel {idx}: downloaded {size/1024:.0f} KB')

    transcript = ''
    if size > 1024 and OPENAI_KEY:
        r = subprocess.run([
            'curl', '-s', '-X', 'POST',
            'https://api.openai.com/v1/audio/transcriptions',
            '-H', f'Authorization: Bearer {OPENAI_KEY}',
            '-F', f'file=@{tmp_audio}',
            '-F', 'model=whisper-1',
            '-F', 'response_format=text'
        ], capture_output=True, encoding='utf-8', errors='replace', timeout=60)
        transcript = r.stdout.strip()

    if not transcript:
        transcript = item.get('caption', '(no transcript)')
        print(f'    Using caption fallback')
    else:
        print(f'    Whisper: {len(transcript)} chars')

    open(out_txt, 'w', encoding='utf-8').write(transcript)
    try: os.remove(tmp_audio)
    except: pass

print('All transcriptions complete.')
PYEOF
```

---

## Step 5 - Run Audit Script and Generate Excel

Save `insta_audit.py` from this skill package to `%USERPROFILE%\AppData\Local\Temp\insta_audit.py` then run:

```bash
python3 "$USERPROFILE/AppData/Local/Temp/insta_audit.py"
```

The script reads from `insta_clean.json` and loads Whisper transcripts from `audit_transcripts/`.
Excel is saved to `Documents/insta_audit_USERNAME_YYYYMMDD_HHMM.xlsx`.

---

## Excel Output - 4 Sheets

| Sheet | Contents |
|-------|----------|
| Dashboard | KPI cards, top 5 reels, bottom 3 reels |
| All Reels | Full ranked table with bar chart |
| Insights | What is working, what needs work, 7-point action plan, posting day table |
| Transcripts | Full spoken text per reel (Whisper or caption fallback), source badge |

---

## Error Handling

| Error | Action |
|-------|--------|
| Missing APIFY_TOKEN | Ask user to set env var |
| Apify FAILED | Check apify.com console for run logs |
| 0 reels found | Account may be private or URL wrong |
| No audioUrl | Caption used as transcript fallback |
| Whisper fails | Caption used as transcript fallback |
| openpyxl not found | Script auto-installs it via pip |

---

## About

Built by Manthan Jethwani - phazeai.com
