import json, sys, os, subprocess, time
from datetime import datetime, timezone, timedelta
from collections import Counter

subprocess.run(['pip', 'install', '-q', 'openpyxl'], capture_output=True)
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

OPENAI_KEY = os.environ.get('OPENAI_API_KEY', '')
tmp_dir = os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Temp')

# ── LOAD DATA ────────────────────────────────────────────────────────
raw_file = os.path.join(tmp_dir, 'insta_clean.json')
with open(raw_file, encoding='utf-8') as f:
    data = json.load(f)

cutoff = datetime.now(timezone.utc) - timedelta(days=30)

# ── TRANSCRIPTION via audioUrl + OpenAI whisper-1 ────────────────────
tdir = os.path.join(tmp_dir, 'audit_transcripts')
os.makedirs(tdir, exist_ok=True)

def transcribe_reel(item, idx):
    audio_url = item.get('audioUrl') or item.get('videoUrl', '')
    caption   = (item.get('caption') or '').strip()

    if not audio_url:
        return caption[:500] if caption else '', 'Caption'

    tmp_audio = os.path.join(tdir, f'reel_{idx}.mp3')
    # Download audio
    dl = subprocess.run(
        ['curl', '-s', '-L', audio_url, '-o', tmp_audio],
        capture_output=True, timeout=60
    )
    if not os.path.exists(tmp_audio) or os.path.getsize(tmp_audio) < 1000:
        return caption[:500] if caption else '', 'Caption'

    if not OPENAI_KEY:
        return caption[:500] if caption else '', 'Caption'

    # Whisper-1 transcription
    r = subprocess.run([
        'curl', '-s', '-X', 'POST',
        'https://api.openai.com/v1/audio/transcriptions',
        '-H', f'Authorization: Bearer {OPENAI_KEY}',
        '-F', f'file=@{tmp_audio}',
        '-F', 'model=whisper-1',
        '-F', 'response_format=text'
    ], capture_output=True, encoding='utf-8', errors='replace', timeout=60)

    transcript = r.stdout.strip()
    if transcript and len(transcript) > 20:
        # Save to file
        with open(os.path.join(tdir, f'reel_{idx}.txt'), 'w', encoding='utf-8') as tf:
            tf.write(transcript)
        return transcript, 'Whisper'

    return caption[:500] if caption else '', 'Caption'

# ── PROCESS REELS ────────────────────────────────────────────────────
reels = []
print(f'Processing {len(data)} items, transcribing audio...')

for idx, item in enumerate(data, 1):
    ts = item.get('timestamp', '')
    try:
        posted = datetime.fromisoformat(ts.replace('Z', '+00:00'))
        if posted < cutoff:
            continue
    except:
        pass

    likes    = int(item.get('likesCount', 0) or 0)
    views    = int(item.get('videoPlayCount', 0) or 0)
    comments = int(item.get('commentsCount', 0) or 0)
    engage   = likes + comments
    eng_rate = round(engage / views * 100, 2) if views > 0 else 0.0
    cap = item.get('caption', '') or ''
    words = cap.split()
    hook = ' '.join(words[:12]) + ('...' if len(words) > 12 else '')

    # Transcribe
    print(f'  [{idx}/{len(data)}] Transcribing reel {idx}...')
    transcript, tx_source = transcribe_reel(item, idx)

    # Day of week
    try:
        dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
        day_name = dt.strftime('%A')
    except:
        day_name = 'Unknown'

    # Caption length bucket
    wc = len(words)
    if wc < 30:    cap_len = 'Short (<30w)'
    elif wc < 100: cap_len = 'Medium (30-100w)'
    else:          cap_len = 'Long (100+w)'

    # Hook type — use transcript if available, else caption
    tl = (transcript or cap).lower()
    if any(tl.startswith(x) for x in ['stop', 'never', "don't", 'warning', 'mistake', 'avoid']):
        hook_type = 'Negative Hook'
    elif any(tl.startswith(x) for x in ['how', 'why', 'what', 'when', 'the truth', 'here']):
        hook_type = 'Educational'
    elif any(tl.startswith(x) for x in ['i ', "i'm", "i've", 'my ']):
        hook_type = 'Personal Story'
    elif any(tl.startswith(x) for x in ['you ', 'your ', 'if you']):
        hook_type = 'Direct Address'
    else:
        hook_type = 'Other'

    # Topic — check both transcript and caption
    combined = (transcript + ' ' + cap).lower()
    topic = 'General'
    topic_map = {
        'AI Tools':       ['ai', 'chatgpt', 'claude', 'gpt', 'llm', 'openai'],
        'Automation':     ['automate', 'automation', 'n8n', 'zapier', 'workflow'],
        'Business':       ['business', 'money', 'income', 'revenue', 'client', 'sales'],
        'Content':        ['content', 'reel', 'video', 'creator', 'caption'],
        'Education':      ['how to', 'tutorial', 'learn', 'tips', 'guide'],
        'Social Media':   ['instagram', 'linkedin', 'twitter', 'followers', 'viral', 'growth'],
        'Personal Brand': ['personal brand', 'brand', 'audience', 'influencer'],
        'Coding/Dev':     ['code', 'coding', 'developer', 'app', 'software'],
    }
    best_score = 0
    for t, keywords in topic_map.items():
        score = sum(combined.count(kw) for kw in keywords)
        if score > best_score:
            best_score = score
            topic = t

    if views == 0:       label = 'No Data'
    elif eng_rate >= 5:  label = 'Viral'
    elif eng_rate >= 3:  label = 'Top Performer'
    elif eng_rate >= 2:  label = 'Good'
    elif eng_rate >= 1:  label = 'Average'
    else:                label = 'Needs Work'

    reels.append({
        'url': item.get('url', ''), 'posted': ts[:10], 'day': day_name,
        'likes': likes, 'views': views, 'comments': comments,
        'engagement': engage, 'eng_rate': eng_rate,
        'caption': cap[:300], 'hook': hook, 'hook_type': hook_type,
        'topic': topic, 'label': label, 'cap_len': cap_len,
        'transcript': transcript, 'tx_source': tx_source,
    })

reels.sort(key=lambda x: x['views'], reverse=True)
total = len(reels)
username = data[0].get('ownerUsername', 'manthanjethwani') if data else 'manthanjethwani'
print(f'Processed {total} reels. Building Excel...')

avg_views    = int(sum(r['views']    for r in reels) / total) if total else 0
avg_likes    = int(sum(r['likes']    for r in reels) / total) if total else 0
avg_comments = int(sum(r['comments'] for r in reels) / total) if total else 0
avg_eng_rate = round(sum(r['eng_rate'] for r in reels) / total, 2) if total else 0
total_views  = sum(r['views'] for r in reels)
top3         = reels[:3]
bottom3      = reels[-3:]

# Day analysis
day_stats = {}
for r in reels:
    d = r['day']
    if d not in day_stats:
        day_stats[d] = {'views': [], 'eng': []}
    day_stats[d]['views'].append(r['views'])
    day_stats[d]['eng'].append(r['eng_rate'])
day_avg = {d: {'avg_views': int(sum(v['views'])/len(v['views'])), 'avg_eng': round(sum(v['eng'])/len(v['eng']),2), 'count': len(v['views'])} for d,v in day_stats.items()}
best_day = max(day_avg, key=lambda d: day_avg[d]['avg_views']) if day_avg else 'N/A'

# Hook type analysis
hook_perf = {}
for r in reels:
    ht = r['hook_type']
    if ht not in hook_perf:
        hook_perf[ht] = []
    hook_perf[ht].append(r['views'])
hook_avg = {h: int(sum(v)/len(v)) for h,v in hook_perf.items()}
best_hook_type = max(hook_avg, key=hook_avg.get) if hook_avg else 'N/A'

# Caption length analysis
cap_perf = {}
for r in reels:
    cl = r['cap_len']
    if cl not in cap_perf:
        cap_perf[cl] = []
    cap_perf[cl].append(r['views'])
cap_avg = {c: int(sum(v)/len(v)) for c,v in cap_perf.items()}
best_cap_len = max(cap_avg, key=cap_avg.get) if cap_avg else 'N/A'

# Topic analysis
topic_perf = {}
for r in reels:
    t = r['topic']
    if t not in topic_perf:
        topic_perf[t] = []
    topic_perf[t].append(r['views'])
topic_avg = {t: int(sum(v)/len(v)) for t,v in topic_perf.items()}
best_topic = max(topic_avg, key=topic_avg.get) if topic_avg else 'General'

# ── DESIGN TOKENS ────────────────────────────────────────────────────
BG       = 'FAFAFA'
DARK     = '0D1117'
NAVY     = '1C2B4A'
ACCENT   = 'FF6B35'
ACCENT2  = '2563EB'
TEAL     = '0EA5A0'
WHITE    = 'FFFFFF'
GRAY_1   = 'F1F5F9'
GRAY_2   = 'E2E8F0'
GRAY_3   = '94A3B8'
GRAY_4   = '475569'
TEXT     = '1E293B'
VIRAL_C  = '7C3AED'
TOP_C    = '059669'
GOOD_C   = '2563EB'
AVG_C    = 'D97706'
BAD_C    = 'DC2626'
NODAT_C  = '9CA3AF'

def hf(c):
    return PatternFill('solid', fgColor=c)

def bdr(color=GRAY_2, style='thin'):
    s = Side(style=style, color=color)
    return Border(left=s, right=s, top=s, bottom=s)

def bdr_bottom(color=GRAY_2):
    s = Side(style='thin', color=color)
    n = Side(style=None)
    return Border(bottom=s, left=n, right=n, top=n)

def ctr(wrap=True):
    return Alignment(horizontal='center', vertical='center', wrap_text=wrap)

def lft(wrap=True):
    return Alignment(horizontal='left', vertical='center', wrap_text=wrap)

def rgt():
    return Alignment(horizontal='right', vertical='center')

def lclr(lbl):
    return {
        'Viral': VIRAL_C, 'Top Performer': TOP_C,
        'Good': GOOD_C, 'Average': AVG_C,
        'Needs Work': BAD_C, 'No Data': NODAT_C
    }.get(lbl, NODAT_C)

def set_cell(ws, addr, value, font=None, fill=None, align=None, border=None):
    c = ws[addr]
    c.value = value
    if font:   c.font   = font
    if fill:   c.fill   = fill
    if align:  c.alignment = align
    if border: c.border = border
    return c

wb = openpyxl.Workbook()

# ════════════════════════════════════════════════════════════════════
# SHEET 1 — EXECUTIVE DASHBOARD
# ════════════════════════════════════════════════════════════════════
ws1 = wb.active
ws1.title = 'Dashboard'
ws1.sheet_view.showGridLines = False
ws1.sheet_view.zoomScale = 85

widths = {'A':2,'B':18,'C':16,'D':16,'E':16,'F':16,'G':16,'H':16,'I':18,'J':18,'K':18,'L':18,'M':2}
for col, w in widths.items():
    ws1.column_dimensions[col].width = w

for r in range(1, 80):
    ws1.row_dimensions[r].height = 18
ws1.row_dimensions[1].height = 8

# Header band
ws1.merge_cells('A2:M2')
ws1['A2'].value = f'  @{username.upper()}  -  INSTAGRAM REELS AUDIT'
ws1['A2'].font = Font(name='Calibri', size=22, bold=True, color=WHITE)
ws1['A2'].fill = hf(DARK)
ws1['A2'].alignment = lft(wrap=False)
ws1.row_dimensions[2].height = 36

ws1.merge_cells('A3:M3')
ws1['A3'].value = f'  Last 30 Days  |  {total} Reels  |  {total_views:,} Total Views  |  Generated {datetime.now().strftime("%d %b %Y")}'
ws1['A3'].font = Font(name='Calibri', size=10, color=GRAY_3)
ws1['A3'].fill = hf(DARK)
ws1['A3'].alignment = lft(wrap=False)
ws1.row_dimensions[3].height = 18

ws1.merge_cells('A4:M4')
ws1['A4'].fill = hf(ACCENT)
ws1.row_dimensions[4].height = 4

ws1.merge_cells('A5:M5')
ws1['A5'].fill = hf(DARK)
ws1.row_dimensions[5].height = 14

# KPI cards
kpi_data = [
    ('B','C', 'REELS POSTED',   str(total),           '↑ 4+/wk target',    TEAL),
    ('D','E', 'TOTAL VIEWS',    f'{total_views:,}',   'last 30 days',       ACCENT2),
    ('F','G', 'AVG VIEWS',      f'{avg_views:,}',     'per reel',           ACCENT),
    ('H','I', 'AVG LIKES',      f'{avg_likes:,}',     'per reel',           TEAL),
    ('J','K', 'AVG ENG. RATE',  f'{avg_eng_rate}%',   'benchmark: 2%+',   '7C3AED'),
]
ws1.row_dimensions[6].height = 6
for c1,c2,label,val,sub,col in kpi_data:
    for row in range(7, 11):
        ws1.merge_cells(f'{c1}{row}:{c2}{row}')
        ws1[f'{c1}{row}'].fill = hf(WHITE)
    ws1[f'{c1}7'].value = ''
    ws1[f'{c1}7'].fill = hf(col)
    ws1.row_dimensions[7].height = 5
    ws1[f'{c1}8'].value = label
    ws1[f'{c1}8'].font = Font(name='Calibri', size=8, bold=True, color=GRAY_3)
    ws1[f'{c1}8'].alignment = ctr()
    ws1.row_dimensions[8].height = 16
    ws1[f'{c1}9'].value = val
    ws1[f'{c1}9'].font = Font(name='Calibri', size=24, bold=True, color=col)
    ws1[f'{c1}9'].alignment = ctr()
    ws1.row_dimensions[9].height = 36
    ws1[f'{c1}10'].value = sub
    ws1[f'{c1}10'].font = Font(name='Calibri', size=8, color=GRAY_3)
    ws1[f'{c1}10'].alignment = ctr()
    ws1.row_dimensions[10].height = 16

ws1.row_dimensions[11].height = 14

def section_header(ws, row, col_start, col_end, title, subtitle=''):
    ws.merge_cells(f'{col_start}{row}:{col_end}{row}')
    ws[f'{col_start}{row}'].value = title
    ws[f'{col_start}{row}'].font = Font(name='Calibri', size=12, bold=True, color=TEXT)
    ws[f'{col_start}{row}'].fill = hf(WHITE)
    ws[f'{col_start}{row}'].alignment = lft(wrap=False)
    ws[f'{col_start}{row}'].border = bdr_bottom(ACCENT)
    ws.row_dimensions[row].height = 26
    if subtitle:
        ws.merge_cells(f'{col_start}{row+1}:{col_end}{row+1}')
        ws[f'{col_start}{row+1}'].value = subtitle
        ws[f'{col_start}{row+1}'].font = Font(name='Calibri', size=9, color=GRAY_3)
        ws[f'{col_start}{row+1}'].alignment = lft(wrap=False)
        ws.row_dimensions[row+1].height = 16
        return row + 2
    return row + 1

def table_header(ws, row, cols_labels, start_col=2):
    ws.row_dimensions[row].height = 24
    for ci, label in enumerate(cols_labels, start_col):
        c = ws.cell(row=row, column=ci)
        c.value = label
        c.font = Font(name='Calibri', size=9, bold=True, color=GRAY_3)
        c.fill = hf(GRAY_1)
        c.alignment = ctr()
        c.border = bdr_bottom(GRAY_2)

# Top performers table
row = 12
row = section_header(ws1, row, 'B', 'L', '  TOP PERFORMING REELS', 'Ranked by total views')
table_header(ws1, row, ['RANK','URL','DATE','VIEWS','LIKES','COMMENTS','ENG. RATE','STATUS','TOPIC','HOOK TYPE'])
row += 1

for rank, r in enumerate(reels[:5], 1):
    ws1.row_dimensions[row].height = 22
    bg = GRAY_1 if rank % 2 == 0 else WHITE
    vals = [rank, r['url'][:50], r['posted'], r['views'], r['likes'],
            r['comments'], f"{r['eng_rate']}%", r['label'], r['topic'], r['hook_type']]
    for ci, v in enumerate(vals, 2):
        c = ws1.cell(row=row, column=ci)
        c.value = v
        c.fill = hf(bg)
        c.alignment = ctr()
        c.border = bdr_bottom()
        c.font = Font(name='Calibri', size=9, color=TEXT)
        if ci == 2:
            c.font = Font(name='Calibri', size=11, bold=True, color=lclr(r['label']))
        if ci == 9:
            c.font = Font(name='Calibri', size=9, bold=True, color=lclr(r['label']))
    row += 1

ws1.row_dimensions[row].height = 14
row += 1

# Needs work table
row = section_header(ws1, row, 'B', 'L', '  REELS THAT NEED WORK', 'Bottom performers — lowest views')
table_header(ws1, row, ['RANK','URL','DATE','VIEWS','LIKES','COMMENTS','ENG. RATE','STATUS','TOPIC','HOOK TYPE'])
row += 1

for rank, r in enumerate(reversed(reels[-3:]), 1):
    ws1.row_dimensions[row].height = 22
    bg = GRAY_1 if rank % 2 == 0 else WHITE
    vals = [rank, r['url'][:50], r['posted'], r['views'], r['likes'],
            r['comments'], f"{r['eng_rate']}%", r['label'], r['topic'], r['hook_type']]
    for ci, v in enumerate(vals, 2):
        c = ws1.cell(row=row, column=ci)
        c.value = v
        c.fill = hf(bg)
        c.alignment = ctr()
        c.border = bdr_bottom()
        c.font = Font(name='Calibri', size=9, color=TEXT)
        if ci == 2:
            c.font = Font(name='Calibri', size=11, bold=True, color=BAD_C)
        if ci == 9:
            c.font = Font(name='Calibri', size=9, bold=True, color=lclr(r['label']))
    row += 1

# ════════════════════════════════════════════════════════════════════
# SHEET 2 — ALL REELS
# ════════════════════════════════════════════════════════════════════
ws2 = wb.create_sheet('All Reels')
ws2.sheet_view.showGridLines = False
ws2.sheet_view.zoomScale = 90

col_ws2 = {'A':2,'B':4,'C':12,'D':52,'E':12,'F':12,'G':12,'H':14,'I':14,'J':16,'K':20,'L':14,'M':40,'N':2}
for col, w in col_ws2.items():
    ws2.column_dimensions[col].width = w

for row in range(1, 4):
    ws2.merge_cells(f'A{row}:N{row}')
    ws2[f'A{row}'].fill = hf(DARK)
ws2['A1'].value = f'ALL REELS  ·  @{username}  ·  Last 30 Days ({total} reels  ·  {total_views:,} total views)'
ws2['A1'].font = Font(name='Calibri', size=14, bold=True, color=WHITE)
ws2['A1'].fill = hf(DARK)
ws2['A1'].alignment = lft(wrap=False)
ws2.row_dimensions[1].height = 32
ws2.row_dimensions[2].height = 4
ws2.merge_cells('A2:N2'); ws2['A2'].fill = hf(ACCENT)
ws2.row_dimensions[3].height = 10

headers = ['#','POSTED','REEL URL','VIEWS','LIKES','COMMENTS','ENGAGEMENT','ENG. RATE %','STATUS','TOPIC','HOOK TYPE','CAPTION PREVIEW']
row = 4
ws2.row_dimensions[row].height = 26
for ci, h in enumerate(headers, 2):
    c = ws2.cell(row=row, column=ci)
    c.value = h
    c.font = Font(name='Calibri', size=9, bold=True, color=WHITE)
    c.fill = hf(NAVY)
    c.alignment = ctr()
    c.border = bdr(NAVY)

for i, r in enumerate(reels, 1):
    row += 1
    ws2.row_dimensions[row].height = 20
    bg = GRAY_1 if i % 2 == 0 else WHITE
    vals = [i, r['posted'], r['url'], r['views'], r['likes'], r['comments'],
            r['engagement'], r['eng_rate'], r['label'], r['topic'], r['hook_type'], r['caption'][:80]]
    for ci, v in enumerate(vals, 2):
        c = ws2.cell(row=row, column=ci)
        c.value = v
        c.fill = hf(bg)
        c.font = Font(name='Calibri', size=9, color=TEXT)
        c.alignment = ctr() if ci != 14 else lft()
        c.border = bdr_bottom()
        if ci == 10:
            c.font = Font(name='Calibri', size=9, bold=True, color=lclr(r['label']))
        if ci == 2:
            c.font = Font(name='Calibri', size=9, bold=True, color=GRAY_3)
        if ci in [5,6,7,8]:
            c.alignment = rgt()

chart_row = len(reels) + 7
ws2.row_dimensions[chart_row].height = 14

data_start_row = 5
chart = BarChart()
chart.type = 'col'
chart.title = 'Views per Reel (Ranked)'
chart.y_axis.title = 'Views'
chart.x_axis.title = 'Reel Rank'
chart.style = 10
chart.grouping = 'clustered'
chart.width = 22; chart.height = 12

data_ref = Reference(ws2, min_col=5, min_row=4, max_row=4+total)
chart.add_data(data_ref, titles_from_data=True)
cats = Reference(ws2, min_col=2, min_row=5, max_row=4+total)
chart.set_categories(cats)
chart.series[0].graphicalProperties.solidFill = ACCENT2
ws2.add_chart(chart, f'B{chart_row+1}')

# ════════════════════════════════════════════════════════════════════
# SHEET 3 — INSIGHTS
# ════════════════════════════════════════════════════════════════════
ws3 = wb.create_sheet('Insights')
ws3.sheet_view.showGridLines = False
ws3.sheet_view.zoomScale = 90

col_ws3 = {'A':2,'B':24,'C':50,'D':4,'E':24,'F':50,'G':2}
for col, w in col_ws3.items():
    ws3.column_dimensions[col].width = w

for row in range(1, 4):
    ws3.merge_cells(f'A{row}:G{row}')
    ws3[f'A{row}'].fill = hf(DARK)
ws3['A1'].value = 'AUDIT INSIGHTS  ·  What Is Working & What Needs Improvement'
ws3['A1'].font = Font(name='Calibri', size=14, bold=True, color=WHITE)
ws3['A1'].fill = hf(DARK); ws3['A1'].alignment = lft(wrap=False)
ws3.row_dimensions[1].height = 32
ws3.merge_cells('A2:G2'); ws3['A2'].fill = hf(ACCENT)
ws3.row_dimensions[2].height = 4
ws3.row_dimensions[3].height = 14

def insight_block(ws, row, col, label, value, detail, color):
    ws[f'{col}{row}'].value = label
    ws[f'{col}{row}'].font = Font(name='Calibri', size=8, bold=True, color=color)
    ws[f'{col}{row}'].fill = hf(WHITE)
    ws[f'{col}{row}'].alignment = lft(wrap=False)
    ws.row_dimensions[row].height = 16
    next_col = chr(ord(col)+1)
    ws[f'{next_col}{row}'].value = ''
    ws[f'{next_col}{row}'].fill = hf(WHITE)
    row += 1
    ws[f'{col}{row}'].value = value
    ws[f'{col}{row}'].font = Font(name='Calibri', size=14, bold=True, color=TEXT)
    ws[f'{col}{row}'].fill = hf(WHITE)
    ws[f'{col}{row}'].alignment = lft(wrap=False)
    ws.row_dimensions[row].height = 22
    row += 1
    ws[f'{col}{row}'].value = detail
    ws[f'{col}{row}'].font = Font(name='Calibri', size=9, color=GRAY_4)
    ws[f'{col}{row}'].fill = hf(WHITE)
    ws[f'{col}{row}'].alignment = lft(wrap=True)
    ws.row_dimensions[row].height = 32
    ws[f'{col}{row}'].border = bdr_bottom(GRAY_2)
    ws[f'{next_col}{row}'].border = bdr_bottom(GRAY_2)
    ws[f'{next_col}{row}'].fill = hf(WHITE)
    row += 1
    ws.row_dimensions[row].height = 8
    return row + 1

def section_hdr3(ws, row, title, color):
    ws.merge_cells(f'B{row}:F{row}')
    ws[f'B{row}'].value = title
    ws[f'B{row}'].font = Font(name='Calibri', size=11, bold=True, color=WHITE)
    ws[f'B{row}'].fill = hf(color)
    ws[f'B{row}'].alignment = lft(wrap=False)
    ws.row_dimensions[row].height = 28
    return row + 1

row = 4
row = section_hdr3(ws3, row, '  WHAT IS WORKING', TOP_C)
ws3.row_dimensions[row].height = 8; row += 1

r_left = row
r_left = insight_block(ws3, r_left, 'B', 'BEST TOPIC', best_topic,
    f'Avg {topic_avg.get(best_topic,0):,} views — focus here for max reach', TOP_C)
r_left = insight_block(ws3, r_left, 'B', 'BEST HOOK TYPE', best_hook_type,
    f'Avg {hook_avg.get(best_hook_type,0):,} views — use this opening style more', TOP_C)
r_left = insight_block(ws3, r_left, 'B', 'AVG ENGAGEMENT RATE', f'{avg_eng_rate}%',
    'Above 2% is strong. Your audience is actively engaging.', TOP_C)

r_right = row
r_right = insight_block(ws3, r_right, 'E', 'BEST POSTING DAY', best_day,
    f'Avg {day_avg.get(best_day,{}).get("avg_views",0):,} views — post more on this day', ACCENT2)
r_right = insight_block(ws3, r_right, 'E', 'BEST CAPTION LENGTH', best_cap_len,
    f'Avg {cap_avg.get(best_cap_len,0):,} views — match this length going forward', ACCENT2)
r_right = insight_block(ws3, r_right, 'E', 'TOP REEL HOOK', top3[0]['hook'] if top3 else 'N/A',
    f'{top3[0]["views"]:,} views  ·  {top3[0]["eng_rate"]}% eng  ·  {top3[0]["posted"]}' if top3 else '', ACCENT2)

row = max(r_left, r_right) + 1
row = section_hdr3(ws3, row, '  WHAT NEEDS IMPROVEMENT', BAD_C)
ws3.row_dimensions[row].height = 8; row += 1

low_eng    = [r for r in reels if r['eng_rate'] < 1.0]
worst_hook = min(hook_avg, key=hook_avg.get) if hook_avg else 'N/A'
worst_day  = min(day_avg,  key=lambda d: day_avg[d]['avg_views']) if day_avg else 'N/A'
posting_freq = round(total/4, 1)
freq_verdict = 'On track' if total >= 16 else ('Room to grow' if total >= 10 else 'Post more often')

r_left = row
r_left = insight_block(ws3, r_left, 'B', 'POSTING FREQUENCY', f'{posting_freq}/week  —  {freq_verdict}',
    f'{total} reels in 30 days. Target 4-5/week for consistent algorithm reach.', BAD_C)
r_left = insight_block(ws3, r_left, 'B', 'WEAKEST HOOK TYPE', worst_hook,
    f'Avg {hook_avg.get(worst_hook,0):,} views — reduce use of this opening style', BAD_C)

r_right = row
r_right = insight_block(ws3, r_right, 'E', 'LOW ENGAGEMENT REELS', f'{len(low_eng)} reels below 1%',
    'These reels lack clear CTAs. End with: "Comment [word] if you want [result]"', BAD_C)
r_right = insight_block(ws3, r_right, 'E', 'WORST POSTING DAY', worst_day,
    f'Avg {day_avg.get(worst_day,{}).get("avg_views",0):,} views — avoid posting on this day', BAD_C)

row = max(r_left, r_right) + 1
row = section_hdr3(ws3, row, '  ACTION PLAN  —  NEXT 30 DAYS', '7C3AED')
ws3.row_dimensions[row].height = 8; row += 1

actions = [
    ('1.  DOUBLE DOWN ON ' + best_topic.upper(),
     f'60% of next month content → {best_topic}. It drives {topic_avg.get(best_topic,0):,} avg views vs your {avg_views:,} avg.'),
    ('2.  USE MORE ' + best_hook_type.upper() + ' HOOKS',
     f'This hook style averages {hook_avg.get(best_hook_type,0):,} views. Start every reel with this pattern.'),
    ('3.  POST ON ' + best_day.upper(),
     f'Best day = {best_day} ({day_avg.get(best_day,{}).get("avg_views",0):,} avg views). Avoid {worst_day} if possible.'),
    ('4.  REPURPOSE TOP REEL',
     f'Your #1 reel got {top3[0]["views"]:,} views. Make a Part 2, deep-dive, or variation of that hook+topic.'),
    ('5.  ADD CTA TO EVERY REEL',
     f'{len(low_eng)} reels have <1% eng. End with: "Comment YES if you want a full breakdown."'),
    ('6.  OPTIMISE CAPTION LENGTH',
     f'Stick to {best_cap_len} captions — they average {cap_avg.get(best_cap_len,0):,} views for you.'),
    ('7.  TRACK MONTHLY',
     'Re-run /insta-audit every 30 days. Compare avg views, eng rate, and top topic month-over-month.'),
]

r_left = row
r_right = row
toggle = True
for act_title, act_detail in actions:
    if toggle:
        r_left = insight_block(ws3, r_left, 'B', act_title, '', act_detail, '7C3AED')
    else:
        r_right = insight_block(ws3, r_right, 'E', act_title, '', act_detail, '7C3AED')
    toggle = not toggle

row = max(r_left, r_right) + 1
row = section_hdr3(ws3, row, '  POSTING DAY BREAKDOWN', NAVY)
ws3.row_dimensions[row].height = 22

day_order = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
for ci, h in enumerate(['DAY','REELS','AVG VIEWS','AVG ENG. RATE'], 2):
    c = ws3.cell(row=row, column=ci)
    c.value = h; c.font = Font(name='Calibri',size=9,bold=True,color=GRAY_3)
    c.fill = hf(GRAY_1); c.alignment = ctr(); c.border = bdr_bottom()
row += 1

for i, d in enumerate(day_order):
    if d not in day_avg:
        continue
    ws3.row_dimensions[row].height = 20
    bg = GRAY_1 if i % 2 == 0 else WHITE
    highlight = d == best_day
    vals = [d, day_avg[d]['count'], f"{day_avg[d]['avg_views']:,}", f"{day_avg[d]['avg_eng']}%"]
    for ci, v in enumerate(vals, 2):
        c = ws3.cell(row=row, column=ci)
        c.value = v
        c.fill = hf('E6F7F2' if highlight else bg)
        c.font = Font(name='Calibri', size=10, bold=highlight, color=TOP_C if highlight else TEXT)
        c.alignment = ctr(); c.border = bdr_bottom()
    row += 1

# ════════════════════════════════════════════════════════════════════
# SHEET 4 — TRANSCRIPTS
# ════════════════════════════════════════════════════════════════════
ws4 = wb.create_sheet('Transcripts')
ws4.sheet_view.showGridLines = False
ws4.sheet_view.zoomScale = 90

ws4.column_dimensions['A'].width = 2
ws4.column_dimensions['B'].width = 5    # rank
ws4.column_dimensions['C'].width = 14   # date
ws4.column_dimensions['D'].width = 52   # url
ws4.column_dimensions['E'].width = 12   # views
ws4.column_dimensions['F'].width = 12   # source badge
ws4.column_dimensions['G'].width = 90   # transcript text
ws4.column_dimensions['H'].width = 2

# Title bar
for r in range(1, 4):
    ws4.merge_cells(f'A{r}:H{r}')
    ws4[f'A{r}'].fill = hf(DARK)
ws4['A1'].value = f'REEL TRANSCRIPTS  ·  @{username}  ·  Last 30 Days  ·  {total} Reels'
ws4['A1'].font = Font(name='Calibri', size=14, bold=True, color=WHITE)
ws4['A1'].fill = hf(DARK)
ws4['A1'].alignment = lft(wrap=False)
ws4.row_dimensions[1].height = 32
ws4.row_dimensions[2].height = 4
ws4.merge_cells('A2:H2'); ws4['A2'].fill = hf(ACCENT)
ws4.row_dimensions[3].height = 10

# Note row
ws4.merge_cells('B4:H4')
ws4['B4'].value = '  Source: "Whisper" = transcribed from audio via OpenAI whisper-1  |  "Caption" = Instagram caption text (audio not available or API key missing)'
ws4['B4'].font = Font(name='Calibri', size=9, color=GRAY_3)
ws4['B4'].alignment = lft(wrap=False)
ws4.row_dimensions[4].height = 20

# Column headers
tx_headers = ['#', 'DATE', 'REEL URL', 'VIEWS', 'SOURCE', 'SPOKEN TRANSCRIPT / CAPTION TEXT']
row = 5
ws4.row_dimensions[row].height = 26
for ci, h in enumerate(tx_headers, 2):
    c = ws4.cell(row=row, column=ci)
    c.value = h
    c.font = Font(name='Calibri', size=9, bold=True, color=WHITE)
    c.fill = hf(NAVY)
    c.alignment = ctr()
    c.border = bdr(NAVY)

# Transcript rows
for i, r in enumerate(reels, 1):
    row += 1
    bg = GRAY_1 if i % 2 == 0 else WHITE
    tx_text = r.get('transcript', '') or r.get('caption', '')[:500]
    tx_source = r.get('tx_source', 'Caption')
    source_color = TEAL if tx_source == 'Whisper' else GRAY_3

    # Calculate row height based on text length
    text_lines = max(3, len(tx_text) // 80 + 1)
    ws4.row_dimensions[row].height = min(text_lines * 15, 120)

    vals = [i, r['posted'], r['url'], r['views'], tx_source, tx_text]
    for ci, v in enumerate(vals, 2):
        c = ws4.cell(row=row, column=ci)
        c.value = v
        c.fill = hf(bg)
        c.border = bdr_bottom()
        if ci == 7:  # transcript text — left align, wrap
            c.font = Font(name='Calibri', size=9, color=TEXT)
            c.alignment = lft(wrap=True)
        elif ci == 6:  # source badge
            c.font = Font(name='Calibri', size=9, bold=True, color=source_color)
            c.alignment = ctr(wrap=False)
        elif ci == 2:  # rank
            c.font = Font(name='Calibri', size=9, bold=True, color=GRAY_3)
            c.alignment = ctr(wrap=False)
        else:
            c.font = Font(name='Calibri', size=9, color=TEXT)
            c.alignment = ctr(wrap=False)

# Summary stats at bottom
row += 2
whisper_count = sum(1 for r in reels if r.get('tx_source') == 'Whisper')
caption_count = total - whisper_count
ws4.merge_cells(f'B{row}:H{row}')
ws4[f'B{row}'].value = f'  Transcription summary: {whisper_count} reels transcribed via Whisper  ·  {caption_count} reels using caption fallback'
ws4[f'B{row}'].font = Font(name='Calibri', size=9, bold=True, color=TEAL)
ws4[f'B{row}'].fill = hf('E6F7F2')
ws4[f'B{row}'].alignment = lft(wrap=False)
ws4.row_dimensions[row].height = 22

# ════════════════════════════════════════════════════════════════════
# SAVE
# ════════════════════════════════════════════════════════════════════
docs = os.path.join(os.path.expanduser('~'), 'Documents')
fname = 'insta_audit_' + username + '_' + datetime.now().strftime('%Y%m%d_%H%M') + '.xlsx'
out = os.path.join(docs, fname)
wb.save(out)

print('Saved: ' + out)
print('Reels: ' + str(total) + ' | Total views: ' + str(total_views) + ' | Avg views: ' + str(avg_views) + ' | Avg eng: ' + str(avg_eng_rate) + '%')
print('Whisper transcripts: ' + str(whisper_count) + ' | Caption fallback: ' + str(caption_count))
if top3:
    print('Top performer: ' + top3[0]['url'] + ' — ' + str(top3[0]['views']) + ' views')
print('Best topic: ' + best_topic + ' | Best day: ' + best_day + ' | Best hook: ' + best_hook_type)
