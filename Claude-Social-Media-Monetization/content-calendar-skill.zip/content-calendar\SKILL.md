# Content Calendar Skill

Create a 30-day reel content calendar as a beautiful, interactive Excel file with trending research baked in.

---

## Step 1: Collect Inputs

Ask in THREE phases. Wait for answers before moving to next phase.

---

### Phase 1 — Basic Setup (ask all 6 together)

1. **Niche/Topic** — What they create content about (e.g. "AI tools for business owners", "skincare for men")
2. **Platform** — Instagram / TikTok / YouTube Shorts / LinkedIn
3. **Posting Frequency** — Daily / 5x a week / 3x a week
4. **30-Day Content Goal** — What they want to achieve this month (e.g. "build personal brand", "establish authority", "promote my service")
5. **Content Style** — Educational / Entertaining / Mix of both
6. **Language** — English / Hinglish / Hindi

Do NOT ask for follower count, revenue goals, or monetization targets.

---

### Phase 2 — Content Direction (ask all 4 together after Phase 1)

1. **Content Ideas You Already Like** — "5 to 7 content ideas ya topics bata jo tujhe personally interesting lagte hain ya jaise content tu banana chahta hai. Kuch bhi — jo tune kahi dekha ho, suna ho, ya khud soch rakha ho." This seeds the calendar with ideas they're already excited about.

2. **Your Exact Audience** — "Tera audience kaun hai specifically? e.g. 'India mein small offline business owners jo online aana chahte hain, 35-50 age' ya 'D2C founders jo paid ads pe zyada kharch kar rahe hain bina ROI ke'" — Be as specific as possible, not just "business owners"

3. **Your Real Expertise** — "Tu personally kya jaanta hai ya karta hai jo dusron ko nahi pata? e.g. 'main ChatGPT se apni customer support automate kar chuka hoon' ya 'maine AI se apni email writing 10x fast ki hai'" — Content written from real experience always wins.

4. **Tools You Actually Use** — "Kaunse AI tools tu khud regularly use karta hai apne business mein? List them out." — This makes content authentic, not generic.

---

### Phase 3 — Research & Boundaries (ask all 3 together after Phase 2)

1. **Content Formats You Prefer** — "Konsa format comfortable hai tere liye? e.g. Talking head (face on camera) / Text overlay only / Screen recording / POV / Voiceover without face" — Affects how every reel is planned.

2. **Upcoming Moments** — "Koi launch, event, announcement, ya important date hai agla 30 din mein jo tu content mein build kar sake? e.g. 'course launch in week 3', 'Diwali season', 'new product coming'" — Calendar will build hype around it.

3. **Hard No's** — "Kya hai jo tu bilkul nahi karna chahta content mein? e.g. 'face nahi dikhana', 'paid tools promote nahi karna', 'koi bhi guarantee wali baat nahi'" — These become strict rules for generation.

Only after ALL THREE phases are answered, proceed to research and generation.

---

## Step 2: Research Trending Topics

Use WebSearch to gather real data before generating anything.

Run these searches (replace [niche] and [platform] with user values):
- `[niche] trending reels ideas [current month] 2025`
- `[niche] viral content [platform] 2025`
- `best performing [niche] reel hooks 2025`
- `[niche] content ideas that get views`

Extract and note:
- Top 8-10 trending topics in their niche
- 10+ viral hooks/opening lines being used
- What content formats are working (talking head, POV, list, tutorial, etc.)
- Any seasonal/timely moments in next 30 days

---

## Step 3: Plan Content Distribution

Distribute 30 reels across 4 content pillars:
- 🔵 **Educational** (40% = 12 reels) — teach, explain, how-to, tips
- 🟡 **Entertainment** (25% = 8 reels) — relatable, humor, trending audio
- 🟢 **Inspirational** (20% = 6 reels) — story, transformation, motivation
- 🟠 **Promotional** (15% = 4 reels) — soft CTA, product/service mention, DM to buy

Map these against posting frequency to fill 30 days (rest days have no reel).

---

## Step 4: Generate All Content

For each of the 30 reels generate:

| Field | What to write |
|---|---|
| **Topic/Title** | Specific, not generic. Bad: "Productivity tips". Good: "5 Claude AI prompts that save me 3 hours a day" |
| **Hook** | Exact first line spoken or shown on screen. Must create curiosity or shock. Max 10 words. |
| **Caption Idea** | 2-3 sentence caption with soft CTA |
| **Hashtags** | 6-8 niche-specific hashtags (not generic like #reels) |
| **Recording Tips** | Specific: angle (eye level / overhead / selfie), background (clean wall / lifestyle), outfit vibe |
| **Tools Needed** | Exactly what equipment: phone + ring light / natural window light / lav mic / etc. |
| **Estimated Duration** | How long to record (e.g. "15 min including retakes") |
| **Editing Style** | Talking head / B-roll montage / Text overlay / Screen recording / POV / Voiceover |
| **Difficulty** | Easy (record in 1 take) / Medium (needs editing) / Hard (b-roll + voiceover) |

Also generate 10 backup reels with the same fields — evergreen ideas for stuck days.

---

## Step 5: Create the Excel File

Write a complete Python script using `openpyxl` and execute it with Bash.

### Sheet 1: Dashboard
- Large title: "[Niche] — 30-Day Reel Calendar"
- Platform + Goal statement in big text
- Pillar breakdown table with percentages and reel counts
- Color legend (which color = which pillar)
- Quick stats box: Total Reels | Posting Days | Rest Days | Avg Difficulty

Design:
- Background: deep purple `#4C1D95`
- Text: white
- Accent cards: `#7C3AED` boxes with white text
- Use merged cells for visual sections

### Sheet 2: 30-Day Calendar (main sheet)

Columns in this order:
`Day | Date | Weekday | Pillar | Topic/Title | Hook 🎯 | Caption | Hashtags | Record Tips 📸 | Tools Needed 🔧 | Est. Duration | Editing Style | Difficulty | Status ✅`

Rules:
- Row 1: frozen header, bold white text on `#4C1D95` background
- Each row color-coded by pillar:
  - Educational = `#DBEAFE` (light blue)
  - Entertainment = `#FEF9C3` (light yellow)
  - Inspirational = `#DCFCE7` (light green)
  - Promotional = `#FFEDD5` (light orange)
  - Rest day = `#F3F4F6` (light gray), text italic
- Status column: data validation dropdown → `Ideas` / `Recording` / `Editing` / `Posted`
- Thick border every 7 rows (weekly separator)
- Column widths: auto-fit to content, min 12, max 40
- Wrap text ON for all content columns

### Sheet 3: Trending Research

Sections:
1. **Trending Topics This Month** — table with Topic | Why It's Trending | Content Angle
2. **Viral Hook Bank** — 15+ hooks they can steal and adapt, with Hook | Type | Why It Works
3. **What's Working Right Now** — format insights from research
4. **Timely Moments** — upcoming dates/events in next 30 days relevant to niche

Design: White background, purple section headers, alternating row shading `#F5F3FF`

### Sheet 4: Recording Guide

Sections with clean table layout:

**By Editing Style:**
| Style | Camera Angle | Background | Lighting | Audio | Avg Edit Time |
|---|---|---|---|---|---|
| Talking Head | Eye level | Clean wall | Ring light front | Lav mic or phone | 20 min |
| POV | Slightly above | Your workspace | Natural light | Ambient ok | 10 min |
| B-Roll Montage | Multiple | Lifestyle | Natural | Voiceover in post | 45 min |
| Screen Recording | N/A | N/A | N/A | Screen audio | 15 min |
| Text Overlay | Any | Aesthetic | Any | Trending audio | 10 min |

**Recommended Apps** table: App | Platform | Free/Paid | Best For
- CapCut (free, all)
- InShot (free, mobile)
- DaVinci Resolve (free, desktop)
- Adobe Premiere Rush (paid, pro)

**Best Posting Times** for their platform (use known data)

**Lighting Setup Guide** — 3 options by budget

Design: Light gray background, purple headers

### Sheet 5: 10 Backup Reels

Same columns as Sheet 2 but only 10 rows.
Header: "🆘 Backup Reels — Use when stuck or missed a day"
Subtitle: "These are evergreen — work any time of year"
Same color coding as main calendar.

---

## Step 6: Save and Deliver

- Filename: `{niche-slug}-30day-reel-calendar.xlsx` (lowercase, hyphens, no spaces)
- Save to current working directory
- Print the full file path
- Tell user:
  - Open in Excel or Google Sheets
  - Start with Sheet 1 Dashboard
  - Update Status column daily as they go
  - Sheet 3 has hooks they can use immediately

---

## Design System Reference

| Element | Color |
|---|---|
| Primary | `#4C1D95` (deep purple) |
| Secondary | `#7C3AED` (medium purple) |
| Accent | `#A78BFA` (light purple) |
| Educational | `#DBEAFE` |
| Entertainment | `#FEF9C3` |
| Inspirational | `#DCFCE7` |
| Promotional | `#FFEDD5` |
| Rest Day | `#F3F4F6` |
| Header Text | `#FFFFFF` |
| Body Text | `#1F2937` |

Font: Calibri throughout. Headers bold size 12, body size 10.

---

## Important Rules

- Every topic must be **specific and scroll-stopping** — never generic
- Hooks must be written as the **exact first words** the creator will say or type on screen
- Recording tips must be **actionable** (not "good lighting" but "face a window, phone at eye level, no overhead lights")
- Research must inform the content — don't make up trends, use what you found in Step 2
- The Excel must be **fully functional** — dropdowns working, colors applied, all 5 sheets populated
